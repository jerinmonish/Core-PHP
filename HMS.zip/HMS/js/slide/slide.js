<script type="text/javascript">
var image1=new Image()
image1.src="dbc1.jpg"
var image2=new Image()
image2.src="dbc2.jpg"
var image3=new Image()
image3.src="dbc3.jpg"
var image4=new Image()
image4.src="dbc4.jpg"
</script>