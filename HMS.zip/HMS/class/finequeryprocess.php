<?php
include_once('dbconnection.php');															// Including the DBconnection

class finequeryprocess extends dbconnection													// Using Inheritance to call DBconnection
{
	
	public $con1;																			// Declaring variables
	public $result1;
	public $sql1;

	public function finequeryprocess()														// Creating Constructor function for finequeryprocess()
	{
		
		$this->con1 = parent::dbconnection();												// Adding the parent Item
		
	}
	
	public function add_fine($fine)															// Creating the function to insert the record in DB
	{
		$sql1 = "insert into sfine(s_name,s_gender,s_datetim,s_fine,s_reason,s_startdate,s_lastdate,s_status)values('".$fine['s_name']."','".$fine['s_gender']."','".$fine['s_datetim']."','".$fine['s_fine']."','".$fine['s_reason']."','".$fine['s_startdate']."','".$fine['s_lastdate']."','".$fine['s_status']."')";
																		
		$result1 = $this->insert($sql1);														// Creating the object to insert()
	}
	
	public function fine_display()																
	{
		$sql1 = "select * from sfine";															
		
		$disp1 = $this->fine_disp($sql1);
		$disp2 = $this->fetch_all($disp1);
		if($disp2)
		{
			return $disp2;
		}
		else
		{
			return false;
		}
	}
	
	public function delete_fine_details($sid)
	{ 
		$sql1 	= "delete from sfine where id=".$sid;
		$result1 = $this->delete_events($sql1);
	}
	
	public function fine_edit($f_id)
	{
		$sql1 = "select * from sfine where id =" .$f_id;
		$disp1 = $this->fine_disp($sql1);
		$res1 = $this->fetch_row($disp1);
		
		if($res1)
		{
			return $res1;
		}
		else
		{
			return false;
		}
	}
	
	public function update_fine($fine)
		{
			$sql1 = "UPDATE sfine set s_name='".$fine['s_name']."',s_gender='".$fine['s_gender']."',s_datetim ='".$fine['s_datetim']."', s_fine = '".$fine[                   's_fine']."' ,s_reason = '".$fine['s_reason']."',s_startdate = '".$fine['s_startdate']."',s_lastdate  = '".$fine['s_lastdate']."',
			        s_status = '".$fine['s_status']."'  WHERE id=".$fine['id'];
		
			$result1 = $this->update_event_details($sql1);
			
		}
}
