<html>
<head>
<link rel="stylesheet" type="text/css" href="css/first.css">
<link rel="stylesheet" href="css/menu.css" />
<title>Event & Fine Management System</title>
<!--<script language="javascript" type="text/javascript" src="js/slide/slide.js">
</script>-->
<script type="text/javascript">
var image1=new Image()
image1.src="images/dbc1.jpg"
var image2=new Image()
image2.src="images/dbc2.jpg"
var image3=new Image()
image3.src="images/dbc3.jpg"
var image4=new Image()
image4.src="images/dbc4.jpg"
</script>
</head>
<body>
<div class="head">
Papa Dhuyon Hostel Events & Fine Management System
</div>
<div class="header">
<img src="images/dbc1.jpg" name="slide" height="200">
<script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<4)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div class="menu">
<ul id="menu">
	<li>
	<a href="index.php">Home</a></li>
	<li> <a href="displayevents.php">Show Events</a>
    <ul class="hidden">
    <li><a href="displayevents.php">Events of the Month</a></li>
    <li><a href="prayers.php">Prayers</a></li>
    </ul>
    </li>
    <li> <a href="displayfine.php">Show Fine</a>
    <ul class="hidden">
    <li><a href="displayfine.php">Fine For the Student</a></li>
    <li><a href="gallery.php">Photography</a></li>
    </ul>
    </li>
    <li>
	<a href="aboutus.php">About Us</a>
	<ul class="hidden">
	<li>
	<a href="aboutus.php">who we are</a></li>
	<li>
	<a href="ouraim.php">what we do</a></li>
	<li>
	<a href="contact.php">Contact Us</a></li>
    </ul>
	</li>
	<li> <a href="adminlogin.php">Admin</a></li>
	</ul>
</div>
<div class="main">
<center><img src="images/images_031.jpg"><br><h3>Fr.Francis Guezou</h3></center>
<p>
<b>Founder of Don Bosco Center, Yelagiri Hills: <i>Fr Francis Guezou</i>, SDB Fr Guezou</b>, a French Salesian missionary came to India in 1952 and was ordained a priest in 1953 at Tirupattur, Tamil Nadu. After ten years of ministry in Yercaud and Kochi, he arrived at Yelagiri Hills and pioneered his work in 1962. Since then he has been the cause of promoting education of the poor, tribal and rural youth at different places of Salesian apostolate in South India. In particular, he founded and strengthened the Salesian educational presence at Yelagiri Hills. Thanks to his patronage, BICS InfoTech was established in 1998 with BIIT and BOSCO ITS as its education and technology units to provide professional compute education to the rural and tribal youth. The contribution of the Association of Friends of Father Guezou in France, founded (in 1964) by Mr Leon Duhayon, a French industrialist is laudable in concretizing the mission of Fr Guezou. The association is currently headed by Mr Stanislaus Ernoult (Director, Decathlon Foundation, France) as the President. Fr Guezou left us on January 29, 2009 for his eternal reward. Yes, his spirit is dynamic and it drives the entire campus. Every visitor to Don Bosco experiences a familiar family spirit, which makes the young, free and natural. This is a heritage that Fr Guezou has passed on. A person of great self-discipline with a touch of humor is a great gift that God has given us. As a Gardener in the Vineyard of the Divine Master, Fr Guezou ploughed hard, planted and watered by the kindness of many selfless friends in France and India and he knows that only God gives the growth. Yelagiri changed him and will change the destiny of people who will dwell here, because God's work is at hand here – it's a God's Mountain of Grace. "Age and arthritis did not stop Fr Guezou from working. Looking around I cannot praise the Lord and thank Fr Guezou and his French benefactors for all these marvels. The last work here, BICS InfoTech, is a model for all. Bringing Information Technology to the poorest! Don Bosco would think exactly like this. May this model be imitated elsewhere, so that we can bring the best of developments to the poorest, particularly in the rural areas." Rev. Fr. Pascual Chavez, SDB (Rector Major - Salesian Society) February 05, 2009 
</p>
</div>
<div class="footer">
<div class="logo">
<table>
<tr><td><a href="dbc@gmail.com" onMouseOver='return confirm("want to Mail?");'><img src="images/socialnet/download (3).jpg" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="dbc/gmail.com" onMouseOver='return confirm("Open FaceBook?");'><img src="images/socialnet/images.png" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="8197980557" onMouseOver='return confirm("want to call?");'><img src="images/socialnet/images.jpg" width="30" height="30" align="left"></a></td></tr>
</table>
</div>
<hr>
<left>
All rights reserved&copy; Papa Dhuyon Hostel Site &reg;<br>
Dated : <?php echo date('d-m-y'); ?><br>
Time <?php echo date('h:i');?></left>

</div>
</body>
</html>