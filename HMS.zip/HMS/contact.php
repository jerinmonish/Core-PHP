<html>
<head>
<link rel="stylesheet" type="text/css" href="css/first.css">
<link rel="stylesheet" href="css/menu.css" />
<title>Event & Fine Management System</title>
<!--<script language="javascript" type="text/javascript" src="js/slide/slide.js">
</script>-->
<script type="text/javascript">
var image1=new Image()
image1.src="images/dbc1.jpg"
var image2=new Image()
image2.src="images/dbc2.jpg"
var image3=new Image()
image3.src="images/dbc3.jpg"
var image4=new Image()
image4.src="images/dbc4.jpg"
</script>
<style>
.con{
	-webkit-column-count:3;
	-moz-column-count:3;
	-column-count:3;
	@float:right;
}
</style>
</head>
<body>
<div class="head">
Papa Dhuyon Hostel Events & Fine Management System
</div>
<div class="header">
<img src="images/dbc1.jpg" name="slide" height="200">
<script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<4)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div class="menu">
<ul id="menu">
	<li>
	<a href="index.php">Home</a></li>
	<li> <a href="displayevents.php">Show Events</a>
    <ul class="hidden">
    <li><a href="displayevents.php">Events of the Month</a></li>
    <li><a href="prayers.php">Prayers</a></li>
    </ul>
    </li>
    <li> <a href="displayfine.php">Show Fine</a>
    <ul class="hidden">
    <li><a href="displayfine.php">Fine For the Student</a></li>
    <li><a href="gallery.php">Photography</a></li>
    </ul>
    </li>
    <li>
	<a href="aboutus.php">About Us</a>
	<ul class="hidden">
	<li>
	<a href="aboutus.php">who we are</a></li>
	<li>
	<a href="ouraim.php">what we do</a></li>
	<li>
	<a href="contact.php">Contact Us</a></li>
    </ul>
	</li>
	<li> <a href="adminlogin.php">Admin</a></li>
  </ul>
</div>
<div class="main">
<pre>
<div class="con">
         
<h2>Thanking you For Supporting Us...</h2>
<img src="images/pdhimages/2.jpg">
<pre>
<h4>Contact Us:</h4>
<img src="images/socialnet/contact.jpg" width="100" height="100">	
            <address>
            Papa Dhuyon Hostel
            Guezou Nagar,Don Bosco Center
            Tirupattur(TK),Vellore(DT),
            Yellagiri Hills-635 853</address>
</pre>
If any Complaint:
<img src="images/socialnet/question-mark.jpg" width="50" height="50">
Mail to PDH <a href="pdh@gmail.com">Click Me!</a>
            
PDH now on
    <a href="pdh/youtube.com"><img src="images/socialnet/download (2).jpg" width="200" height="100"></a>
</pre>
<div class="lef" style="float:right">
Follow Us On:
			
         <a href="pdhskype.com"><img src="images/socialnet/images (2).jpg" width="50" height="50"></a>
         <a href="pdh@yahoo.com"><img src="images/socialnet/download.jpg" width="50" height="50"></a>
         <a href="pdh/hike.com"><img src="images/socialnet/Hike.JPG" width="50" height="50"></a>
         <a href="pdh/twitter.com"><img src="images/socialnet/images (3).jpg" width="50" height="50"></a>
         <a href="pdh/line.com"><img src="images/socialnet/line.JPG" width="50" height="50"></a>
         <a href="pdh/viber.com"><img src="images/socialnet/wiber.JPG" width="50" height="50"></a></div>
<br><br>
With Best Regards:
         <marquee direction="right">
         <img src="images/pdhimages/FILE646.JPG" width="200" height="200">
         <img src="images/pdhimages/FILE648.JPG" width="200" height="200">
         <img src="images/pdhimages/FILE1048.JPG" width="200" height="200">
         </marquee>        
</div>
 