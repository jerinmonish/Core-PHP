<html>
<head>
<link rel="stylesheet" type="text/css" href="css/first.css">
<link rel="stylesheet" href="css/menu.css" />
<title>Event & Fine Management System</title>
<!--<script language="javascript" type="text/javascript" src="js/slide/slide.js">
</script>-->
<script type="text/javascript">
var image1=new Image()
image1.src="images/dbc1.jpg"
var image2=new Image()
image2.src="images/dbc2.jpg"
var image3=new Image()
image3.src="images/dbc3.jpg"
var image4=new Image()
image4.src="images/dbc4.jpg"
</script>
</head>
<body>
<div class="head">
Papa Dhuyon Hostel Events & Fine Management System
</div>
<div class="header">
<img src="images/dbc1.jpg" name="slide" width="1350" height="200">
<script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<4)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div class="menu">
<ul id="menu">
	<li>
	<a href="index.php">Home</a></li>
	<li> <a href="displayevents.php">Show Events</a>
    <ul class="hidden">
    <li><a href="displayevents.php">Events of the Month</a></li>
    <li><a href="prayers.php">Prayers</a></li>
    </ul>
    </li>
    <li> <a href="displayfine.php">Show Fine</a>
    <ul class="hidden">
    <li><a href="displayfine.php">Fine For the Student</a></li>
    <li><a href="gallery.php">Photography</a></li>
    </ul>
    </li>
    <li>
	<a href="aboutus.php">About Us</a>
	<ul class="hidden">
	<li>
	<a href="aboutus.php">who we are</a></li>
	<li>
	<a href="ouraim.php">what we do</a></li>
	<li>
	<a href="contact.php">Contact Us</a></li>
    </ul>
	</li>
	<li> <a href="adminlogin.php">Admin</a></li>
	</ul>
</div>
<div class="main">
<dl>
<dt>About Us:</dt>
Papa Dhuyon Hostel, Yelagiri Hills (DBCY) is a minority Hostel, managed by the Salesians of Don Bosco of Chennai Province. It is part of Don Bosco College of Arts and Science College. The college has over 16 years of experience in innovative educational pedagogy and industrial expertise specifically in computer education.
</dl>
<pre>
<b>Our History</b>

FIFTEEN YEARS AGO (in 1998), the Don Bosco community envisioned that the employability of rural youth can be improved by imparting quality education with<br> professional skills. In view of this vision, BICS InfoTech was established with the patronage of Fr Francis Guezou in 1998; a non-formal Computer Training and<br> a Software Development Centre were established to provide professional education, admitting sixty students per year for the one-year and three-year <br>academic programmes. Later in 1999, BICS signed to setup CDAC-Pune and IGNOU Special Study centres.

The institute gradually evolved and began to function under three major wings: Professional Education by Bosco Institute of Information Technology (BIIT) that<br> prepared the students to become employable in IT industry and IT-enabled service (IT-ES) industries and obtain degree from IGNOU on part-time basis;<br> Software Development by Bosco InfoTech Services (BOSCO ITS); Knowledge Resource Centre (Arivagam in 2007).<br>

In preparing the students for IGNOU BCA Degree, BIIT offered an additional Postgraduate Diploma in Information Technology (PGDIT). BIIT has educated 1000 rural<br> students graduate in Professional Higher Education. It's a divine mediation that in the 50th year of Fr Guezou's arrival (1962-2012 at Yelagiri Hills), <br>BICS InfoTech was upgraded to Don Bosco College, affiliated to Thiruvalluvar University. The inception of Don Bosco College at Yelagiri Hills is a golden <br>milestone in the history of Don Bosco Centre (Yelagiri Hills) providing higher education services to more students as regular college.

<b>TIMELINE</b>
<ol type="I">
<li>[1962] Fr. Francis Guezou arrived at Yelagiri Hills during the late evening on December 31, 1962; practically alone and impoverished.</li>

<li>[1998] BICS InfoTech was  established with the patronage of Fr Francis Guezou; BIIT as a non-formal software training division that prepared the students to<br> become employable in IT industry  and IT-enabled service (IT-ES) industries and obtain degree from IGNOU on part-time basis and BOSCO ITS<br> as its education and technology units.</li>

<li>[1999] BICS InfoTech signed a contract with CDAC, Pune (Centre for Development in Advanced Computing, an autonomous body of the Ministry of<br> Information Technology, Government of India) to provide skill based training in IT.  A Special Study Centre of <br>IGNOU (Indira Gandhi National Open University) was  constituted at Yelagiri Hills to enable <br>students to do their degree program better.</li>

<li>[2000] Bosco Institute of Information Technology (BIIT), <br>while preparing the students for BCA,  offers an additional Postgraduate Diploma in Information Technology (PGDIT), adhering to rigorous academic <br>discipline with a special curriculum designed according to the growing need of the software industry, approved by a formally constituted academic council. <br>So far, BIIT has enabled over 900 rural students graduate in Professional Higher Education and have found a successful niche for their life.,</li>

<li>[2012] Don Bosco College, Yelagiri is inaugurated as affiliated College  of Thiruvaluvar University.</li>

</ol>
</pre>
</div>
<div class="footer">
<div class="logo">
<table>
<tr><td><a href="dbc@gmail.com" onMouseOver='return confirm("want to Mail?");'><img src="images/socialnet/download (3).jpg" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="dbc/gmail.com" onMouseOver='return confirm("Open FaceBook?");'><img src="images/socialnet/images.png" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="8197980557" onMouseOver='return confirm("want to call?");'><img src="images/socialnet/images.jpg" width="30" height="30" align="left"></a></td></tr>
</table>
</div>
<hr>
<left>
All rights reserved&copy; Papa Dhuyon Hostel Site &reg;<br>
Dated : <?php echo date('d-m-y'); ?><br>
Time <?php echo date('h:i');?></left>
</div>
</body>
</html>