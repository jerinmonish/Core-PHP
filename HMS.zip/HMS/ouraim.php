<html>
<head>
<link rel="stylesheet" type="text/css" href="css/first.css">
<link rel="stylesheet" href="css/menu.css" />
<title>Event & Fine Management System</title>
<!--<script language="javascript" type="text/javascript" src="js/slide/slide.js">
</script>-->
<script type="text/javascript">
var image1=new Image()
image1.src="images/dbc1.jpg"
var image2=new Image()
image2.src="images/dbc2.jpg"
var image3=new Image()
image3.src="images/dbc3.jpg"
var image4=new Image()
image4.src="images/dbc4.jpg"
</script>
</head>
<body>
<div class="head">
Papa Dhuyon Hostel Events & Fine Management System
</div>
<div class="header">
<img src="images/dbc1.jpg" name="slide" width="1350" height="200">
<script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<4)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div class="menu">
<ul id="menu">
	<li>
	<a href="index.php">Home</a></li>
	<li> <a href="displayevents.php">Show Events</a>
    <ul class="hidden">
    <li><a href="displayevents.php">Events of the Month</a></li>
    <li><a href="prayers.php">Prayers</a></li>
    </ul>
    </li>
    <li> <a href="displayfine.php">Show Fine</a>
    <ul class="hidden">
    <li><a href="displayfine.php">Fine For the Student</a></li>
    <li><a href="gallery.php">Photography</a></li>
    </ul>
    </li>
    <li>
	<a href="aboutus.php">About Us</a>
	<ul class="hidden">
	<li>
	<a href="aboutus.php">who we are</a></li>
	<li>
	<a href="ouraim.php">what we do</a></li>
	<li>
	<a href="contact.php">Contact Us</a></li>
    </ul>
	</li>
	<li> <a href="adminlogin.php">Admin</a></li>
  </ul>
</div>
<div class="main">

<dt>
<dl>VISION</dl>

A Temple of Higher Education, nurturing the integrated persons, inspired by Gospel Values.
</dt>
<dt>
<dl>MISSION</dl>

Educating the target youth with qualitative knowledge, practice and experience to become integrated persons for career and life. In pursuit of this,<br> we offer programmes and services of best-in-class standards.
</dt>
<dt>
<dl>OBJECTIVES</dl>
<pre>
    1)To educate and train at certificate, diploma, undergraduate and postgraduate levels, professionals of outstanding ability with integral values.
    2)To facilitate all-round formation of the students through multiple, integrated education programmes and activities
    3)To develop students as true agents of social transformation in their specific settings.
    4)To promote research and development in leading edge information technology and its applications.
    5)To partner with social and educational institutes that promote development of rural India in an innovative way
    6)To develop economic programmes  for the sustainability and scalability of the institute.
</pre>
</dt>
<dt>
<dl>CORE VALUES</dl>
<pre>
    1)Primacy for God in Life
    2)Integral Formation
    3)Commitment to Nation-building
    4)Quality Service
</pre>
</dt>
<dt>
<dl>DISTINCTNESS</dl>

<dd>Don Bosco College is a state-of-the-art and preferred institution for higher education in a conducive hill environment. The following are the characteristics<br> that differentiate DBCY as class-apart and inimitable higher educational institution.
</dd>
<pre>
    1)Affordable education fee
    2)Indigenous system to acquire communication and English language skills
    3)Qualified, experienced and dedicated faculty members
    4)Industrial exposure and opportunities to work on live projects
    5)Better job opportunities in IT and IT-enabled organizations
</pre>
</dt>
</div>
<div class="footer">
<div class="logo">
<table>
<tr><td><a href="dbc@gmail.com" onMouseOver='return confirm("want to Mail?");'><img src="images/socialnet/download (3).jpg" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="dbc/gmail.com" onMouseOver='return confirm("Open FaceBook?");'><img src="images/socialnet/images.png" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="8197980557" onMouseOver='return confirm("want to call?");'><img src="images/socialnet/images.jpg" width="30" height="30" align="left"></a></td></tr>
</table>
</div>
<hr>
<left>
All rights reserved&copy; Papa Dhuyon Hostel Site &reg;<br>
Dated : <?php echo date('d-m-y'); ?><br>
Time <?php echo date('h:i');?></left>

</div>
</body>
</html>