<html>
<head>
<title>Prayers</title>
<link rel="stylesheet" type="text/css" href="css/first.css">
<link rel="stylesheet" href="css/menu.css" />
<title>Event & Fine Management System</title>
<!--<script language="javascript" type="text/javascript" src="js/slide/slide.js">
</script>-->
<script type="text/javascript">
var image1=new Image()
image1.src="images/dbc1.jpg"
var image2=new Image()
image2.src="images/dbc2.jpg"
var image3=new Image()
image3.src="images/dbc3.jpg"
var image4=new Image()
image4.src="images/dbc4.jpg"
</script>
</head>
<body>
<div class="head">
Papa Dhuyon Hostel Events & Fine Management System
</div>
<div class="header">
<img src="images/dbc1.jpg" name="slide" height="200">
<script type="text/javascript">
var step=1
function slideit(){
document.images.slide.src=eval("image"+step+".src")
if(step<4)
step++
else
step=1
setTimeout("slideit()",2500)
}
slideit()
</script>
</div>
<div class="menu">
<ul id="menu">
	<li>
	<a href="index.php">Home</a></li>
	<li> <a href="displayevents.php">Show Events</a>
    <ul class="hidden">
    <li><a href="displayevents.php">Events of the Month</a></li>
    <li><a href="prayers.php">Prayers</a></li>
    </ul>
    </li>
    <li> <a href="displayfine.php">Show Fine</a>
    <ul class="hidden">
    <li><a href="displayfine.php">Fine For the Student</a></li>
    <li><a href="gallery.php">Photography</a></li>
    </ul>
    </li>
    <li>
	<a href="aboutus.php">About Us</a>
	<ul class="hidden">
	<li>
	<a href="aboutus.php">who we are</a></li>
	<li>
	<a href="ouraim.php">what we do</a></li>
	<li>
	<a href="contact.php">Contact Us</a></li>
    </ul>
	</li>
	<li> <a href="adminlogin.php">Admin</a></li>
	</ul>
</div>
<div class="main">
<table border="1" style="border-collapse:collapse" align="center">
<tr>
<td>
<pre>
<h3 align="center"><u>Birthday Prayer</u></h3>
O God,
I thank you for giving me another year of life.
I thank you for all the people
who have remembered me today,
and who have sent me cards,
letters, good wishes and presents.
I thank you for everything
which I have been enabled by you to do
and to be in the past year.


I thank you for all the experiences
of the past year;
For times of success
which will always be my memories;
for times of failure
which reminded me of my weakness
and of my need of you;
for times of joy when the sun was shining;
for the times of sorrows which drove me to you.


Forgive me for the hours I have wasted;
for the chance I failed to take;
for the opportunities I missed in the past year.
Forgive me that I have not made of life
all that I might have made of it
and could have made of it;
to make this the best year yet,
And in it to credit to myself,
happiness to my loved ones
and joy to you.
This I ask for Jesus' sake.
				
 †Amen.
 </pre>
 </td>
 <td style="float:right; margin-top:0px;">
 <pre>
 <h3 align="center"><u>Prayer</u></h3>
 Loving Father,
Source of all wisdom,
help me to use my time
and my intelligence wisely
as I prepare for my exams.
Help me to dispose myself
to listen to Your Holy Spirit,
so that You, as my Loving Father,
may place me in a state of prayer
and lead me to understand
that the supreme wisdom
is knowing I am Your child.
Help me to remain serene
so that my work may truly reflect
this profound truth.
Mary, Mother of my spiritual life,
guide me in the ways of your Son,
so that my work may help
to transform this world for His 
         glory.
Amen.

 </td>
 <td style="float:right; margin-top:0px;"><h3 align="center"><u>Prayer Before an Exam</u></h3>
Dear Lord,
Sometimes I feel a little strange praying
to you because of an exam.
It doesn't really seem all that significant
when you consider the "big picture."
But right now, the test looms so large
that it is all I can see before me.
I pray to you for three things:
- the strength to handle the pressure that I feel,
- the confidence to feel secure in my knowledge and 	                                                                                                                                                     preparation,
- and the ability to keep an appropriate perspective on it all.
   Help me to keep in mind what is really important,
   even as I focus all of my time and energy
   on this test in the immediate future. 
Amen

 </td>
 </tr>       
</table>
</div>
<div class="footer">
<div class="logo">
<table>
<tr><td><a href="dbc@gmail.com" onMouseOver='return confirm("want to Mail?");'><img src="images/socialnet/download (3).jpg" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="dbc/gmail.com" onMouseOver='return confirm("Open FaceBook?");'><img src="images/socialnet/images.png" width="30" height="30" align="left"></a></td></tr>
<tr><td><a href="8197980557" onMouseOver='return confirm("want to call?");'><img src="images/socialnet/images.jpg" width="30" height="30" align="left"></a></td></tr>
</table>
</div>
<hr>
<left>
All rights reserved&copy; Papa Dhuyon Hostel Site &reg;<br>
Dated : <?php echo date('d-m-y'); ?><br>
Time <?php echo date('h:i');?></left>
</div>
</body>
</html>